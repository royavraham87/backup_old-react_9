from django.shortcuts import render
from django.http import JsonResponse
from rest_framework.response import Response
from rest_framework.decorators import api_view
from .models import Product
from rest_framework import serializers

@api_view(['GET'])
def index(req):
    return Response({'msg':'hello'})


class ProductSerializer(serializers.ModelSerializer):
    class Meta:
        model = Product
        fields = '__all__'

@api_view(['GET'])
def products(req):
    pro_product=Product.objects.all()
    return Response (ProductSerializer(pro_product,many=True).data)

@api_view(['POST'])
def addproduct(req):
    pro_product = ProductSerializer(data=req.data)
    if pro_product.is_valid():
        pro_product.save()
        return Response ("post...")

@api_view(['DELETE'])
def delproduct(req,id=-1):
    pro_product=Product.objects.get(id=id)
    pro_product.delete()
    return Response ("del...")
